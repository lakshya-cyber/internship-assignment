from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from typing import List
from datetime import datetime

app = FastAPI()
reports = {}  # in-memory store

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/report")
async def receive_report(request: Request):
    data = await request.json()
    machine_id = data.get("machine_id")
    data["received_at"] = datetime.utcnow().isoformat()
    reports[machine_id] = data
    return {"message": "Report received"}

@app.get("/machines")
async def get_all_reports():
    return list(reports.values())
