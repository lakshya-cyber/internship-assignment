import platform
import subprocess
import json
import time
import uuid
import requests
from datetime import datetime

# API to send report (we'll create this soon)
API_URL = "http://localhost:8000/report"
MACHINE_ID = str(uuid.getnode())

def check_os():
    return platform.system()

def check_disk_encryption():
    os_name = check_os()
    if os_name == "Linux":
        try:
            output = subprocess.check_output("lsblk -o NAME,TYPE,FSTYPE", shell=True).decode()
            return 'crypt' in output
        except:
            return False
    elif os_name == "Darwin":  # macOS
        try:
            output = subprocess.check_output("fdesetup status", shell=True).decode()
            return 'FileVault is On' in output
        except:
            return False
    return None

def check_antivirus():
    return None  # Most Linux/macOS systems don't have a standard AV

def check_sleep_settings():
    return None  # Skip for now

def check_os_update_status():
    return False  # You can later add `apt list --upgradable` logic

def collect_status():
    return {
        "machine_id": MACHINE_ID,
        "os": check_os(),
        "disk_encryption": check_disk_encryption(),
        "os_up_to_date": check_os_update_status(),
        "antivirus_enabled": check_antivirus(),
        "sleep_setting_ok": check_sleep_settings(),
        "timestamp": datetime.utcnow().isoformat(),
    }

def send_status(data):
    try:
        response = requests.post(API_URL, json=data)
        print("Reported to server:", response.status_code)
    except Exception as e:
        print("Failed to send:", e)

def main():
    last_status = {}
    while True:
        status = collect_status()
        if status != last_status:
            send_status(status)
            last_status = status
        time.sleep(60)

if __name__ == "__main__":
    main()
